﻿namespace ScriptableArchitect.Events
{
    /// <summary>
    /// A class that listens for events of type float.
    /// </summary>
    public class FloatEventListener : EventListener<float> { }
}